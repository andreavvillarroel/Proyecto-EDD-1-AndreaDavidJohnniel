/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Funciones;

import EDD.Grafo;
import EDD.Lista;
import EDD.Vertice;

/**
 *
 * @author Moises Liota
 */
public class GestionApp {

    public Lista nombresEstacionesSinSucursal(Grafo grafo) {
        if (!grafo.isEmpty()) {
            Lista nombres = new Lista();
            for (int i = 0; i < grafo.getVertices().getSize(); i++) {
                Vertice vertice = (Vertice) grafo.getVertices().getValor(i);
                if (!vertice.isTieneSucursal()) {
                    nombres.insertarFinal(vertice.getNombre());
                }
            }
            return nombres;
        }
        return null;
    }

    public Lista nombresEstacionesSucursal(Grafo grafo) {
        if (!grafo.isEmpty()) {
            Lista nombres = new Lista();
            for (int i = 0; i < grafo.getVertices().getSize(); i++) {
                Vertice vertice = (Vertice) grafo.getVertices().getValor(i);
                if (vertice.isTieneSucursal()) {
                    nombres.insertarFinal(vertice.getNombre());
                }
            }
            return nombres;
        }
        return null;
    }

    public Lista nombresEstaciones(Grafo grafo) {
        if (!grafo.isEmpty()) {
            Lista nombres = new Lista();
            for (int i = 0; i < grafo.getVertices().getSize(); i++) {
                Vertice vertice = (Vertice) grafo.getVertices().getValor(i);

                nombres.insertarFinal(vertice.getNombre());

            }
            return nombres;
        }
        return null;
    }
}
